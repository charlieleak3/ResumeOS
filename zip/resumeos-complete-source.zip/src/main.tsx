import React, { useState } from 'react';
import ReactDOM from 'react-dom/client';
import { UserProfile, ResumeBlock, ThemePreference } from './types';
import { THEME_PALETTES } from './themeEngine';
import { BlockCanvas } from './components/BlockCanvas';
import { ProfileSwitcher } from './components/ProfileSwitcher';

const initialProfiles: UserProfile[] = [
  { id: '1', name: 'Alex Mercer', themePreference: 'default', createdAt: new Date().toISOString() },
  { id: '2', name: 'Sarah Mercer', themePreference: 'teal', createdAt: new Date().toISOString() },
];

const initialBlocks: Record<string, ResumeBlock[]> = {
  '1': [
    { id: 'b1', title: 'Senior Software Engineer - TechCorp', content: 'Architected microservices handling 1M+ daily active users.', tags: ['#react', '#node', '#cloud'] },
    { id: 'b2', title: 'Freelance & Independent Consulting Hub', content: 'Delivered 12+ client projects under contract umbrella headers.', tags: ['#freelance', '#consulting'] }
  ],
  '2': [
    { id: 'b1', title: 'Product Designer - Studio UX', content: 'Designed design systems for enterprise mobile apps.', tags: ['#figma', '#ux', '#research'] }
  ]
};

function App() {
  const [profiles, setProfiles] = useState<UserProfile[]>(initialProfiles);
  const [activeProfileId, setActiveProfileId] = useState<string>('1');
  const [blocks, setBlocks] = useState<Record<string, ResumeBlock[]>>(initialBlocks);

  const activeProfile = profiles.find(p => p.id === activeProfileId) || profiles[0];
  const currentTheme = THEME_PALETTES[activeProfile.themePreference];

  const handleSelectProfile = (id: string) => {
    setActiveProfileId(id);
  };

  const handleUpdateTheme = (newTheme: ThemePreference) => {
    setProfiles(prev => prev.map(p => p.id === activeProfileId ? { ...p, themePreference: newTheme } : p));
  };

  const handleUpdateBlock = (updatedBlock: ResumeBlock) => {
    setBlocks(prev => ({
      ...prev,
      [activeProfileId]: prev[activeProfileId].map(b => b.id === updatedBlock.id ? updatedBlock : b)
    }));
  };

  const currentBlocks = blocks[activeProfileId] || [];

  return (
    <div style={{ minHeight: '100vh', backgroundColor: currentTheme.bgMain, color: currentTheme.textPrimary, fontFamily: 'sans-serif', transition: 'all 0.2s ease' }}>
      <ProfileSwitcher
        activeProfile={activeProfile}
        profiles={profiles}
        onSelectProfile={handleSelectProfile}
        onUpdateTheme={handleUpdateTheme}
      />

      <main style={{ maxWidth: '800px', margin: '2rem auto', padding: '1rem' }}>
        <BlockCanvas blocks={currentBlocks} onUpdateBlock={handleUpdateBlock} />
      </main>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')!).render(<App />);
