import React from 'react';
import { UserProfile, ThemePreference } from '../types';
import { THEME_PALETTES, applyTheme } from '../themeEngine';

interface ProfileSwitcherProps {
  activeProfile: UserProfile;
  profiles: UserProfile[];
  onSelectProfile: (profileId: string) => void;
  onUpdateTheme: (theme: ThemePreference) => void;
}

export const ProfileSwitcher: React.FC<ProfileSwitcherProps> = ({
  activeProfile,
  profiles,
  onSelectProfile,
  onUpdateTheme,
}) => {
  const themes: ThemePreference[] = ['default', 'navy', 'teal', 'midnight', 'monochrome'];

  return (
    <header style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '1rem 2rem', backgroundColor: 'var(--bg-surface, #fff)', borderBottom: '1px solid var(--border-color, #e2e8f0)' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
        <h1 style={{ fontSize: '1.25rem', fontWeight: 'bold', margin: 0, color: 'var(--accent-color, #2563eb)' }}>ResumeOS</h1>
        <span style={{ fontSize: '0.875rem', color: 'var(--text-secondary, #475569)' }}>Active Profile:</span>
        <select
          value={activeProfile.id}
          onChange={(e) => onSelectProfile(e.target.value)}
          style={{ padding: '0.4rem 0.8rem', borderRadius: '4px', border: '1px solid var(--border-color, #e2e8f0)', backgroundColor: 'var(--bg-main, #f8fafc)', color: 'var(--text-primary, #0f172a)' }}
        >
          {profiles.map((p) => (
            <option key={p.id} value={p.id}>
              👤 {p.name}
            </option>
          ))}
        </select>
      </div>

      <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
        <span style={{ fontSize: '0.85rem', color: 'var(--text-secondary, #475569)' }}>Persistent Theme:</span>
        {themes.map((themeKey) => (
          <button
            key={themeKey}
            style={{
              width: '22px',
              height: '22px',
              borderRadius: '50%',
              border: activeProfile.themePreference === themeKey ? '2px solid var(--accent-color, #2563eb)' : '2px solid transparent',
              backgroundColor: THEME_PALETTES[themeKey].accentColor,
              cursor: 'pointer',
              transform: activeProfile.themePreference === themeKey ? 'scale(1.2)' : 'scale(1)',
              transition: 'transform 0.1s ease'
            }}
            onClick={() => {
              applyTheme(themeKey);
              onUpdateTheme(themeKey);
            }}
            title={themeKey}
          />
        ))}
      </div>
    </header>
  );
};
